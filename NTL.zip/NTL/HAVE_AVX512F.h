#ifndef NTL_HAVE_AVX512F
#define NTL_HAVE_AVX512F
#endif
