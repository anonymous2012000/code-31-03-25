#ifndef NTL_HAVE_SSSE3
#define NTL_HAVE_SSSE3
#endif
