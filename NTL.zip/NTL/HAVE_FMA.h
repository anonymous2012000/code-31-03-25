#ifndef NTL_HAVE_FMA
#define NTL_HAVE_FMA
#endif
